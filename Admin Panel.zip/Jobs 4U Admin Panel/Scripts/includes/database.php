<?php 
include("rb.php");
R::setup('mysql:host=localhost;dbname=job_portal', 'root', '');
?>