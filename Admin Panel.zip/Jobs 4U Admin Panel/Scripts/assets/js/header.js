const signOut   =   document.querySelector(".signOut-span");

signOut.addEventListener("click", ()    =>
{
        location.href = "./sign_out.php";
});