<?php
session_start();
include("includes/database.php");
include("includes/functions.php");

// $config['base_url']     =   "job_portal/";
$config['admin_url']    =   "job_portal/admin/";
$config["user_url"]     =   "";
// $config['site_name']    =   "Jobs Portal";
// Include function files
// include("includes/functions.php");

?>